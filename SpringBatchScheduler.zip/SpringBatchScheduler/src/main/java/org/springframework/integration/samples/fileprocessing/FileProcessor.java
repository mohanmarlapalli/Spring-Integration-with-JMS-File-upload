/**
 * 
 */
package org.springframework.integration.samples.fileprocessing;

import java.io.File;
import java.util.Random;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;

import com.demo.util.StudentThread;

/**
 * @author ozhurakousky
 *
 */
public class FileProcessor {
	
	static final Logger LOG = LoggerFactory.getLogger(FileProcessor.class);
	
	@Autowired
	AbstractApplicationContext context ;

	@Autowired
	private StudentThread studentThread;
	
	public File process(File file) throws Exception{	

		LOG.info("Processing File: " + file);
		studentThread.executeFile(file.getAbsolutePath());
		            
		return file;
	}
}
