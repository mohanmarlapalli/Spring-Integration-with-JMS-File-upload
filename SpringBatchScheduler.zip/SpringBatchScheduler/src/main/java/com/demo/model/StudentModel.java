package com.demo.model;

import java.io.Serializable;

public class StudentModel implements Serializable {

	private static final long serialVersionUID = 1L;

	private String studentName;

	private String studentRoleNo;

	private String semistor;

	private String payment;

	private String status;
	
	private String fileNameandLine;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentRoleNo() {
		return studentRoleNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFileNameandLine() {
		return fileNameandLine;
	}

	public void setFileNameandLine(String fileNameandLine) {
		this.fileNameandLine = fileNameandLine;
	}

	public void setStudentRoleNo(String studentRoleNo) {
		this.studentRoleNo = studentRoleNo;
	}

	public String getSemistor() {
		return semistor;
	}

	public void setSemistor(String semistor) {
		this.semistor = semistor;
	}

	public String getPayment() {
		return payment;
	}

	public void setPayment(String payment) {
		this.payment = payment;
	}

}
