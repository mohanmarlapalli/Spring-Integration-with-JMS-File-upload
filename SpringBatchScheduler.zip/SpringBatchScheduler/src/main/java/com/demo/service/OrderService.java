package com.demo.service;

import com.demo.model.StudentModel;

public interface OrderService {

	public void processOrder(StudentModel product);
}
