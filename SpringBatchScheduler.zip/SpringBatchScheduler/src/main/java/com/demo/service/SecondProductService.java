package com.demo.service;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.demo.jms.messaging.SecondMessageSender;
import com.demo.model.StudentModel;
import com.demo.model.StudentAddress;
import com.demo.util.StudenAddressModelMapper;

@Service("secondProductService")
public class SecondProductService implements ProductService{

	static final Logger LOG = LoggerFactory.getLogger(SecondProductService.class);
	
	private static String sql="select address_1,address_2,city,State,country from Student_Address where roll_number=?";
	
	@Autowired
	SecondMessageSender secondMessageSender;
	@Autowired
	private DataSource dataSource;
	
	
	
	public void sendProduct(StudentModel product) {

		LOG.info("Application : sending order request {}", product);
		
		try{
			JdbcTemplate myTemplate = new JdbcTemplate(dataSource);
		StudentAddress studentAddress = (StudentAddress)myTemplate.queryForObject(sql, new Object[] { product.getStudentRoleNo() }, new StudenAddressModelMapper());
		studentAddress.setStudentRoleNo(product.getStudentRoleNo());
		studentAddress.setStudentName(product.getStudentName());
		studentAddress.setStatus(product.getStatus());
		studentAddress.setSemistor(product.getSemistor());
		studentAddress.setPayment(product.getPayment());
		secondMessageSender.sendMessage(studentAddress);
		}catch(Exception e){
			LOG.error("Error while getting values from DB");
		}
		LOG.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
	}

	
	
}
