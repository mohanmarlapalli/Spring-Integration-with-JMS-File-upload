package com.demo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.jms.messaging.MessageSender;
import com.demo.model.StudentModel;

@Service("orderService")
public class OrderServiceImpl implements OrderService{

	static final Logger LOG = LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Autowired
	MessageSender messageSender;
	
	public void processOrder(StudentModel product) {
		
		LOG.info("Inventory : sending order confirmation {}", product);
		messageSender.sendMessage(product);
	}
	
	
	
}
