package com.demo.service;

import com.demo.model.StudentModel;

public interface ProductService {

	public void sendProduct(StudentModel product);
	
	
}
