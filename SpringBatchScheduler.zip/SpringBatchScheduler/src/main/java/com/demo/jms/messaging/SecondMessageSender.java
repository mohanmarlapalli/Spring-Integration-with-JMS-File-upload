package com.demo.jms.messaging;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Session;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.demo.model.StudentAddress;

@Component
public class SecondMessageSender {

	@Autowired
	@Qualifier("secondJmsTemplate")
	JmsTemplate secondJmsTemplate;

	public void sendMessage(final StudentAddress studentAddress) {

		secondJmsTemplate.send(new MessageCreator(){
				public Message createMessage(Session session) throws JMSException{
					ObjectMessage objectMessage = session.createObjectMessage(studentAddress);
					
					return objectMessage;
				}
			});
	}

}
