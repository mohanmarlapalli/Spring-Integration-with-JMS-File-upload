package com.demo.jms.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.demo.jms.consumer.configuration.ConsumerMessagingConfiguration;
import com.demo.jms.consumer.configuration.MessagingListnerConfiguration;

@Configuration
@ComponentScan(basePackages = "com.demo")
@Import({ConsumerMessagingConfiguration.class,ConsumerMessagingConfiguration.class, MessagingListnerConfiguration.class,SecondMessagingConfiguration.class})
public class AppConfig {
	
	//Put Other Application configuration here.
}
