package com.demo.jms.consumer.messaging;

import javax.jms.JMSException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import com.demo.model.StudentModel;
import com.demo.service.OrderService;
import com.demo.service.SecondProductService;


@Component
public class consumerMessageReceiver {

	static final Logger LOG = LoggerFactory.getLogger(consumerMessageReceiver.class);
	private static final String ORDER_QUEUE = "aa";
	
	@Autowired
	OrderService orderService;
	
	@Autowired
	SecondProductService secondProductService;

	@JmsListener(destination = ORDER_QUEUE)
	public void receiveMessage(final Message<StudentModel> message) throws JMSException {
		LOG.info("----------------------------------------------------");
		MessageHeaders headers =  message.getHeaders();
		LOG.info("Application : headers received : {}", headers);
		
		StudentModel product = message.getPayload();
		LOG.info("Application : product : {}",product);	
		secondProductService.sendProduct(product);
//		orderService.processOrder(product);
		LOG.info("----------------------------------------------------");

	}
	
}
