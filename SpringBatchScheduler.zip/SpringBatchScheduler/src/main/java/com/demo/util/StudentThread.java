package com.demo.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.demo.model.StudentModel;
import com.demo.service.ProductService;
import com.opencsv.CSVReader;
@Component
public class StudentThread {

	static final Logger LOG = LoggerFactory.getLogger(StudentThread.class);

	@Autowired
	private DataSource dataSource;

	private String sql = "INSERT INTO student_payment "
			+ "(student_name, roll_number,payment, semester) VALUES (?, ?, ?,?)";

	@Autowired
	ProductService productService;

	/*public StudentThread(String fileame, DataSource dataSource,
			AbstractApplicationContext context) {
		this.fileame = fileame;
		this.dataSource = dataSource;
		this.context = context;
		productService = (ProductService) context.getBean("productService");
	}*/

	public void executeFile(String fileame) {

		CSVReader reader = null;
		try {
			System.out.println(fileame);
			reader = new CSVReader(new FileReader(fileame), ',');
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		List<StudentModel> emps = new ArrayList<StudentModel>();

		// read line by line
		String[] record = null;
		JdbcTemplate myTemplate = new JdbcTemplate(dataSource);
		try {
			int i = 1;
			while ((record = reader.readNext()) != null) {
				StudentModel emp = new StudentModel();
				try {
					emp.setStudentName(record[0]);
					emp.setStudentRoleNo(record[1]);
					emp.setSemistor(record[2]);
					emp.setPayment(record[3]);
					emps.add(emp);
					System.out.println(record[0] + record[1] + record[2]);
					emp.setStatus("success");
				} catch (Exception e) {
					emp.setStatus("error");
					LOG.error("Error in line number" + i + " File name "
							+ fileame);

				}

				myTemplate.update(
						sql,
						new Object[] { emp.getStudentName(),
								emp.getStudentRoleNo(), emp.getPayment(),
								emp.getStudentName() });

				LOG.info("database saved successfully");

				emp.setFileNameandLine(fileame + " Line Number" + i);

				productService.sendProduct(emp);

				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
