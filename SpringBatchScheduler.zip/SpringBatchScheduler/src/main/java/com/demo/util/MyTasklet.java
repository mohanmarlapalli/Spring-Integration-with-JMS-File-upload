package com.demo.util;

import javax.sql.DataSource;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.AbstractApplicationContext;
@Configuration
public class MyTasklet implements Tasklet{
	
	private DataSource dataSource;
	private String folderName = "D:\\mohan\\csv\\";
	@Autowired
	AbstractApplicationContext context ;


	public RepeatStatus execute(StepContribution contribution,
			ChunkContext chunkContext) throws Exception {
				
		
		return RepeatStatus.FINISHED;
	}


	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	

}
