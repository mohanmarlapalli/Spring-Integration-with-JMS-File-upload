package com.demo.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;

public class MyScheduler {
	
	static final Logger LOG = LoggerFactory.getLogger(MyScheduler.class);

	@Autowired
	private JobLauncher launcher;
	
	@Autowired
	private Job job;
	
	private JobExecution execution;
	
	public void run(){
		try {
			execution = launcher.run(job, new JobParameters());
			LOG.info("Execution status: "+ execution.getStatus());
		} catch (Exception e) {
			LOG.error("Error while processing");
		}
	}
}
