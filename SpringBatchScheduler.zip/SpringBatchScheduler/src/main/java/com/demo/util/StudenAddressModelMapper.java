package com.demo.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.demo.model.StudentModel;
import com.demo.model.StudentAddress;

public class StudenAddressModelMapper implements RowMapper<StudentAddress>{

	public StudentAddress mapRow(ResultSet rs, int rowNum) throws SQLException {
		StudentAddress studentAddress = new StudentAddress();
		studentAddress.setAddress1(rs.getString("address_1"));
		studentAddress.setAddress2(rs.getString("address_2"));
		studentAddress.setCity(rs.getString("city"));
		studentAddress.setState(rs.getString("State"));
		studentAddress.setCountry(rs.getString("country"));
		return studentAddress;
	}

}
