package com.demo.app;

import java.io.IOException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.messaging.PollableChannel;

public class App {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException {
	      
		String[] str = {"classpath:META-INF/spring/job-config.xml","classpath:META-INF/spring/context-config.xml","classpath:META-INF/spring/concurrentFileProcessing-config.xml"};
		ApplicationContext ctx = new ClassPathXmlApplicationContext(str);	
		
		PollableChannel filesOutChannel = ctx.getBean("filesOutChannel", PollableChannel.class);
			System.out.println("Finished processing " + filesOutChannel.receive(10000).getPayload());
	}
}
