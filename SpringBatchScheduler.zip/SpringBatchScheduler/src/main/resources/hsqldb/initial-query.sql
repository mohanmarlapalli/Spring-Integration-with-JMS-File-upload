DROP TABLE person IF EXISTS;
DROP TABLE Student_Address IF EXISTS;
DROP TABLE STUDENT_PAYMENT IF EXISTS;

CREATE TABLE person (
firstName VARCHAR(20),
lastName VARCHAR(20),
school VARCHAR(20),
rollNumber int);

CREATE TABLE Student_Address (
roll_number VARCHAR(20),
address_1 VARCHAR(200),
address_2 VARCHAR(200),
city VARCHAR(100),
pincode VARCHAR(10),
State VARCHAR(100),
country VARCHAR(100));

CREATE TABLE STUDENT_PAYMENT(STUDENT_NAME VARCHAR(20),roll_number VARCHAR(20),PAYMENT VARCHAR(20),SEMESTER VARCHAR(5))


INSERT INTO Student_Address VALUES ('100','#675/a,2nd main,3rd right','Marathahalli','Bangalore','560036','Karnataka','India');
INSERT INTO Student_Address VALUES ('101','#675/a,2nd main,3rd right','Marathahalli','Bangalore','560036','Karnataka','India');
INSERT INTO Student_Address VALUES ('102','#676/a,2nd main,3rd right,Marathahalli','Marathahalli','Bangalore','560036','Karnataka','India');
INSERT INTO Student_Address VALUES ('11','#676/a,2nd main,3rd right,Marathahalli','Marathahalli','Bangalore','560036','Karnataka','India');
INSERT INTO Student_Address VALUES ('10','#676/a,2nd main,3rd right,Marathahalli','Marathahalli','Bangalore','560036','Karnataka','India');