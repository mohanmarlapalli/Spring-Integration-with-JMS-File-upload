package com.cardsofwar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class CardsOfWarGameBusinessObj {
	

	/*
	  Output: Get all 52 cards into the game
	*/
	public static List<PlayingCard> getAllCards() {

		List<PlayingCard> allCards = new ArrayList<PlayingCard>(); // create an ArrayList of all cards

		for (int x = 0; x < 4; x++) { // 0-3 for suit (4 suits)
			for (int y = 2; y < 15; y++) { // 2-14 for rank (13 ranks)
				allCards.add(new PlayingCard(x, y)); // create new card and add into the deck
			}
		}
		
		// shuffle the deck randomly
		Collections.shuffle(allCards, new Random()); 

		return allCards;
	}

	
	/*
	 * noOfPersons : No.of persons playing the game
	 * coutCards : No.of cards for each player
	 * allCards : all 52 cards
	  Output: Share the cards to no.of people
	*/
	public static LinkedList<PlayingCard>[] dynamicNoofPersonsCardShare(
			int noOfPersons, int coutCards, List<PlayingCard> allCards) {
		//create linked list array for no..of people
		@SuppressWarnings("unchecked")
		LinkedList<PlayingCard>[] noOfPersonsLinkedLists = new LinkedList[noOfPersons];
		int count = noOfPersons;
		for (int i = 0; i < 52;) {
			LinkedList<PlayingCard> deck = new LinkedList<PlayingCard>();
			
			deck.addAll(allCards.subList(i, (i += coutCards)));
			noOfPersonsLinkedLists[--count] = deck;
		}
		return noOfPersonsLinkedLists;
	}
	
	
	/*
	 * noOfPersonsLinkedLists : No.of persons array playing the game
	 * noOfPersons : No.of persons in the game
	  Output: No.of persons present in the game
	*/
	public static int noOfPersonsInGame(
			LinkedList<PlayingCard>[] noOfPersonsLinkedLists, int noOfPersons) {
		int noOfPersonsPresentGame = 0;
		for (int i = 0; i < noOfPersons; i++) {
			if (noOfPersonsLinkedLists[i].size() != 0) {
				noOfPersonsPresentGame++;
			}
		}
		return noOfPersonsPresentGame;
	}
   
	
	/*
	 * noOfPersonsLinkedLists : No.of persons array playing the game
	 * noOfPersons : No.of persons in the game
	 * player :who won the round
	 * rounds : no.of round playing the player
	  Output: Execute the round and winner takes the cards
	*/
	public static boolean checkTheroundWinner(
			LinkedList<PlayingCard>[] noOfPersonsLinkedLists, int noOfPersons,
			int player, int rounds) {

		boolean warCondition = true;
		Integer max = null;
		int start = 0;
		
		player = 1;
		int noOfPersonsPresentGame = noOfPersonsInGame(noOfPersonsLinkedLists,
				noOfPersons);
		if (noOfPersonsPresentGame >= noOfPersons) {
			noOfPersonsPresentGame = noOfPersons;
		}

		if (noOfPersonsPresentGame > 1) {
			for (; start < noOfPersonsLinkedLists.length; start++) {
				if (noOfPersonsLinkedLists[start].size() >= 1) {
					max = noOfPersonsLinkedLists[start].pop().getCard();
				}
			}
			int countTheEquls = 1;
			for (int i = 1; i < noOfPersons; i++) {
				if (noOfPersonsLinkedLists[i].size() >= 1)
					if (noOfPersonsLinkedLists[i].get(0).getCard() > max) {
						max = noOfPersonsLinkedLists[i].get(0).getCard();
						warCondition = false;
						player = i + 1;
					} else if (noOfPersonsLinkedLists[i].get(0).getCard() == max) {
						countTheEquls++;
					}
			}
			if (countTheEquls != noOfPersonsPresentGame)
				for (int i = 0; i < noOfPersons; i++) {
					if (i != player - 1) {
						if (noOfPersonsLinkedLists[i].size() > 0)
							noOfPersonsLinkedLists[player - 1]
									.addLast(noOfPersonsLinkedLists[i].pop());
					}
				}
			System.out.println(" Rounds : " + rounds + " player won : "
					+ player + " No.Of persons in this round: "
					+ noOfPersonsPresentGame);
		}
		return warCondition;
	}
	
	
	/*
	 * noOfPersonsLinkedLists : No.of persons array playing the game
	 * noOfPersons : No.of persons in the game
	  Output: Won the player name will check this method
	*/
	public static int wonPlayerName(
			LinkedList<PlayingCard>[] noOfPersonsLinkedLists, int noOfPersons) {
		List<Integer> noOfPersonsOver = new ArrayList<>();
		int wonPlayer = 0;
		//Adding into the list to check no.of persons playing currently
		for (int i = 0; i < noOfPersonsLinkedLists.length; i++) {
			if (noOfPersonsLinkedLists[i].size() == 0) {
				noOfPersonsOver.add(i + 1);
			}
		}
		//
			for (int i = 1; i <= noOfPersons; i++) {
				if (!noOfPersonsOver.contains(i)) {
					wonPlayer = i;
			}
		}
		return wonPlayer;
	}
	

	/*
	 * noOfPersonsLinkedLists : No.of persons array playing the game
	 * noOfPersons : No.of persons in the game
	  Output: war condition
	*/
	public static void warBussinessLogic(LinkedList<PlayingCard>[] noOfPersonsLinkedLists,int noOfPersonsPresentGame){
		
		List<List<PlayingCard>> lists = new ArrayList<>();
		for (int i = 0; i < noOfPersonsPresentGame; i++) {
			lists.add(new ArrayList<PlayingCard>());
		}
		// creating war cards

		// checking do players have enough (4)cards to stay in game
		for (int x = 0; x < noOfPersonsPresentGame; x++) {
			for (int i = 0; i < 3 ; i++) {
				if(noOfPersonsLinkedLists[x].size() != 0){
					lists.get(x).add(noOfPersonsLinkedLists[x].pop());
				}
			}
		// either one player runs out of card is game over
		}// end for
//		rounds ++;

		// only compare result when both players have enough
		// cards for war
		int max = lists.get(0).size() > 2 ? lists.get(0).get(2).getCard() : 0;
		int player=1;	
		for (int i = 1; i < noOfPersonsPresentGame; i++) {
			if( lists.get(i).size() > 2){
			if( lists.get(i).get(2).getCard() > max){
				 max = lists.get(i).get(2).getCard();
				 player = i+1;
			}
			}
		}
		
		for (int i = 0; i < noOfPersonsPresentGame; i++) {
			if(i != player-1 )
		noOfPersonsLinkedLists[player-1].addAll(lists.get(i));
		}
	}
}
