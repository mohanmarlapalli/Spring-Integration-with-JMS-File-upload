package com.cardsofwar;

 
import java.util.LinkedList; //import LinkList
import java.util.List; //import List
import java.util.Scanner;

public class CardsOfWarGame {
	
	
	public static String excuteCardGame(Integer noOfPersons) {

		if (noOfPersons == null) {
			return "Enter values";
		} else {
			if (noOfPersons > 1 && noOfPersons <= 52) {

				int modCount = 52 % noOfPersons;

				if (modCount == 0) {
					//Counting no.of cards per person
					int coutCards = 52 / noOfPersons;
					//Get all 52 cards 
					List<PlayingCard> cardDeck = CardsOfWarGameBusinessObj.getAllCards();
					//Sharing cards to person
					LinkedList<PlayingCard>[] noOfPersonsLinkedLists = CardsOfWarGameBusinessObj.dynamicNoofPersonsCardShare(noOfPersons, coutCards, cardDeck);
				
					int rounds = 0;
					int player=1;
					while (true) {

						 player=1;
						//Check the round without war condition
						boolean warCondition = CardsOfWarGameBusinessObj.checkTheroundWinner(noOfPersonsLinkedLists, noOfPersons, player, rounds);
						rounds++;
						//No.of persons in present round
						int noOfPersonsPresentGame =  CardsOfWarGameBusinessObj.noOfPersonsInGame(noOfPersonsLinkedLists, noOfPersons);
						if(noOfPersonsPresentGame < 2){
							break;
						}
						if(  warCondition ){
							System.out.println("Entering into War conditon");
							//int warConditionNoOfPersonsPresent = WarCardGameBusinessObj.warConditionToCheckPersonsPresentInGame(noOfPersonsLinkedLists, noOfPersons);
							/*noOfPersonsPresentGame =  CardsOfWarGameBusinessObj.noOfPersonsInGame(noOfPersonsLinkedLists, noOfPersons);
							if( noOfPersonsPresentGame == 1){
								break;
							}*/
							
							CardsOfWarGameBusinessObj.warBussinessLogic(noOfPersonsLinkedLists, noOfPersonsPresentGame);
							
							noOfPersonsPresentGame =  CardsOfWarGameBusinessObj.noOfPersonsInGame(noOfPersonsLinkedLists, noOfPersons);
							if(noOfPersonsPresentGame == 1){
								break;
							}
						}


					}// end while
					System.out.println("player "+CardsOfWarGameBusinessObj.wonPlayerName(noOfPersonsLinkedLists, noOfPersons)+" won");
				} else {
					return "Person count is not proper";
				}
			} else {
				return "Person should be 1 to 52";
			}
			return "success";
		}

	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No.of players");
		Integer noOfPlayers = sc.nextInt();
		System.out.println(excuteCardGame(noOfPlayers));
	}// end main
}// end WarCardGame class
