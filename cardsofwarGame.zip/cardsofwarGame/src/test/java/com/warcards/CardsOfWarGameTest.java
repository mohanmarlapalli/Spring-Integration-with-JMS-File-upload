package com.warcards;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cardsofwar.CardsOfWarGame;

@SuppressWarnings("static-access")
public class CardsOfWarGameTest {
	
	private static CardsOfWarGame WarCardGamw;
	
	@BeforeClass
	public static void initCalculator() {
		WarCardGamw = new CardsOfWarGame();
	}
	
	@Test
	public void testZeroPersons() {
		String result = WarCardGamw.excuteCardGame(0);
		assertEquals("Person should be 1 to 52", result);
	}
	
	@Test
	public void testNegativePersons() {
		String result = WarCardGamw.excuteCardGame(-1);
		assertEquals("Person should be 1 to 52", result);
	}
	
	@Test
	public void testPositivePersons() {
		String result = WarCardGamw.excuteCardGame(2);
		assertEquals("success", result);
	}
	
	@Test
	public void testNullPersons() {
		String result = WarCardGamw.excuteCardGame(null);
		assertEquals("Enter values", result);
	}
	
	@Test
	public void testProperPersons() {
		String result = WarCardGamw.excuteCardGame(3);
		assertEquals( "Person count is not proper", result);
	}
}
