package com.warcards.bussiness;

import static org.junit.Assert.assertEquals;

import java.util.LinkedList;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cardsofwar.CardsOfWarGameBusinessObj;
import com.cardsofwar.PlayingCard;

public class CardsOfWarGameObjTest {

	private static List<PlayingCard> result = null;
	private static LinkedList<PlayingCard>[] dynamicallyCalculatePersons = null;
	
	@BeforeClass
	public static void initCalculator() {
		result = CardsOfWarGameBusinessObj.getAllCards();
	}
	
	@Test
	public void testAllCards() {
		assertEquals(52, result.size());
	}
	
	@Test
	public void dynamicNoofPersonscalculationTest() {
		int noofPersons = 4;
		int coutCards = result.size() / noofPersons;
		dynamicallyCalculatePersons = CardsOfWarGameBusinessObj.dynamicNoofPersonsCardShare(noofPersons, coutCards, result);
		assertEquals(noofPersons, dynamicallyCalculatePersons.length);
	}
	
	
	@Test
	public void checkTheroundWinner() {
		int noOfPersons = 4;
		boolean result = CardsOfWarGameBusinessObj.checkTheroundWinner(dynamicallyCalculatePersons, noOfPersons, 1, 1);
		if(result)
			assertEquals(true,result);
		else
			assertEquals(false,result);
	}
	
	@Test
	public void noOfPersonsInGameTest() {
		int noOfPersons = 4;
		int noOfPersonsPresenInGame = CardsOfWarGameBusinessObj.noOfPersonsInGame(dynamicallyCalculatePersons, noOfPersons);
			assertEquals(noOfPersons,noOfPersonsPresenInGame);
	}
	
	@Test
	public void warBussinessLogicTest() {
		int noOfPersons = 4;
		 CardsOfWarGameBusinessObj.warBussinessLogic(dynamicallyCalculatePersons, 4);
//			assertEquals(noOfPersons,noOfPersonsPresenInGame);
	}
	
	
}
